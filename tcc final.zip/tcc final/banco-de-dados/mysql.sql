id-- Criando o banco de dados (opcional, caso ainda não tenha um)
CREATE DATABASE IF NOT EXISTS ags_motoboy CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Selecionando o banco de dados para usar
USE ags_motoboy;

-- -----------------------------------------------------
-- Tabela `usuarios`
-- Armazena todos os dados coletados no formulário de inscrição.
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome_completo` VARCHAR(255) NOT NULL,
  `nickname` VARCHAR(100) NOT NULL UNIQUE,
  `cpf` VARCHAR(14) NOT NULL UNIQUE COMMENT 'Armazena formatado: xxx.xxx.xxx-xx',
  `cep` VARCHAR(9) NOT NULL COMMENT 'Armazena formatado: xxxxx-xxx',
  `data_nascimento` DATE NOT NULL,
  `sexo` ENUM('masculino', 'feminino', 'outro') NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `senha_hash` VARCHAR(255) NOT NULL COMMENT 'NUNCA armazene a senha em texto plano. Sempre use um hash (ex: bcrypt).',
  `foto_perfil_url` TEXT NULL COMMENT 'URL ou caminho para a imagem de perfil do usuário.',
  `data_cadastro` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;


-- -----------------------------------------------------
-- Tabela `corridas`
-- Armazena os detalhes de cada corrida solicitada por um usuário.
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS corridas (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario_id` INT UNSIGNED NOT NULL COMMENT 'Chave estrangeira que referencia o ID do usuário que pediu a corrida.',
  `endereco_retirada` TEXT NOT NULL,
  `endereco_destino` TEXT NOT NULL,
  `peso_kg` DECIMAL(5, 2) NOT NULL COMMENT 'Peso da encomenda em quilogramas.',
  `distancia_km` DECIMAL(10, 2) NULL COMMENT 'Distância calculada da rota em quilômetros.',
  `valor_total` DECIMAL(10, 2) NULL COMMENT 'Preço final da corrida.',
  `status` ENUM('solicitada', 'em_andamento', 'concluida', 'cancelada') NOT NULL DEFAULT 'solicitada',
  `avaliacao` TINYINT UNSIGNED NULL COMMENT 'Nota da corrida, de 1 a 5 estrelas.',
  `data_solicitacao` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_corridas_usuarios`
    FOREIGN KEY (`usuario_id`)
    REFERENCES `usuarios` (`id`)
    ON DELETE CASCADE -- Se um usuário for deletado, suas corridas também serão.
    ON UPDATE NO ACTION
) ENGINE=InnoDB;