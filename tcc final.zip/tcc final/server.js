// server.js (Versão com Autenticação JWT e Variáveis de Ambiente)

// 1. IMPORTAÇÃO DOS MÓDULOS
require('dotenv').config(); // <-- NOVO: Carrega as variáveis do arquivo .env
const fs = require('fs');
const https = require('https');
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const path = require('path');
const jwt = require('jsonwebtoken');

// 2. CONFIGURAÇÃO DO SERVIDOR EXPRESS
const app = express();
const PORT = 3000;
// A chave secreta agora é lida de forma segura do arquivo .env
const JWT_SECRET = process.env.JWT_SECRET; // <-- MODIFICADO

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 3. CONEXÃO COM O BANCO DE DADOS
// Os dados da conexão agora vêm de forma segura do arquivo .env
const db = mysql.createPool({
    host: process.env.DB_HOST,         // <-- MODIFICADO
    user: process.env.DB_USER,         // <-- MODIFICADO
    password: process.env.DB_PASSWORD, // <-- MODIFICADO
    database: process.env.DB_DATABASE, // <-- MODIFICADO
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
}).promise();

// 4. MIDDLEWARE DE AUTENTICAÇÃO
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) {
        return res.status(401).json({ success: false, message: 'Acesso negado. Nenhum token fornecido.' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ success: false, message: 'Token inválido ou expirado.' });
        }
        req.user = user;
        next();
    });
};

// 5. ROTAS

// Rotas públicas (não precisam de autenticação)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index1.html'));
});

app.post('/register', async (req, res) => {
    const { nome, nickname, cpf, cep, nascimento, sexo, email, senha } = req.body;
    if (!nome || !nickname || !cpf || !cep || !nascimento || !sexo || !email || !senha) { return res.status(400).json({ success: false, message: 'Todos os campos são obrigatórios!' }); }
    const hoje = new Date(); const dataNascimento = new Date(nascimento); let idade = hoje.getFullYear() - dataNascimento.getFullYear(); const m = hoje.getMonth() - dataNascimento.getMonth(); if (m < 0 || (m === 0 && hoje.getDate() < dataNascimento.getDate())) { idade--; } if (idade < 18) { return res.status(400).json({ success: false, message: 'O cadastro não é permitido para menores de 18 anos.' }); }
    try {
        const salt = await bcrypt.genSalt(10); const senhaHash = await bcrypt.hash(senha, salt);
        const sql = `INSERT INTO usuarios (nome_completo, nickname, cpf, cep, data_nascimento, sexo, email, senha_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
        await db.query(sql, [nome, nickname, cpf, cep, nascimento, sexo, email, senhaHash]);
        res.status(201).json({ success: true, message: 'Usuário cadastrado com sucesso!' });
    } catch (error) { console.error('Erro no servidor ao registrar:', error); if (error.code === 'ER_DUP_ENTRY') { return res.status(409).json({ success: false, message: 'CPF, Nickname ou E-mail já cadastrado.' }); } res.status(500).json({ success: false, message: 'Erro interno no servidor.' }); }
});

// Rota de Login
app.post('/login', async (req, res) => {
    const { usuario, senha } = req.body;
    if (!usuario || !senha) { return res.status(400).json({ success: false, message: 'Usuário e senha são obrigatórios.' }); }
    try {
        const sql = 'SELECT id, nickname, email, senha_hash FROM usuarios WHERE email = ? OR nickname = ?';
        const [rows] = await db.query(sql, [usuario, usuario]);
        if (rows.length === 0) { return res.status(404).json({ success: false, message: 'Usuário não encontrado.' }); }
        const user = rows[0];
        const senhaCorreta = await bcrypt.compare(senha, user.senha_hash);
        if (!senhaCorreta) { return res.status(401).json({ success: false, message: 'Senha incorreta.' }); }

        const payload = {
            id: user.id,
            nickname: user.nickname
        };

        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '8h' });

        res.status(200).json({
            success: true,
            message: 'Login bem-sucedido!',
            token: token
        });

    } catch (error) { console.error('Erro no servidor ao fazer login:', error); res.status(500).json({ success: false, message: 'Erro interno no servidor.' }); }
});

// Rota de exemplo protegida por autenticação
app.get('/api/dados-usuario', authenticateToken, async (req, res) => {
    try {
        const sql = 'SELECT id, nome_completo, nickname, email, foto_perfil_url FROM usuarios WHERE id = ?';
        const [rows] = await db.query(sql, [req.user.id]);

        if (rows.length > 0) {
            res.json({ success: true, user: rows[0] });
        } else {
            res.status(404).json({ success: false, message: 'Usuário não encontrado no banco de dados.' });
        }
    } catch (error) {
        console.error('Erro ao buscar dados do usuário:', error);
        res.status(500).json({ success: false, message: 'Erro interno do servidor.' });
    }
});

// NOVA ROTA PARA SALVAR O PERFIL (ainda sem upload de imagem)
app.post('/api/profile', authenticateToken, async (req, res) => {
    // NOTA: Esta é uma versão simples. O upload de arquivos (foto)
    // exige um middleware extra como o 'multer'.
    // Por enquanto, ele apenas atualiza o nickname.
    const { nickname } = req.body;
    
    if (!nickname) {
        return res.status(400).json({ success: false, message: 'Nickname é obrigatório.' });
    }

    try {
        const sql = 'UPDATE usuarios SET nickname = ? WHERE id = ?';
        await db.query(sql, [nickname, req.user.id]);
        res.json({ success: true, message: 'Perfil atualizado com sucesso!' });
    } catch (error) {
        console.error('Erro ao atualizar perfil:', error);
        res.status(500).json({ success: false, message: 'Erro interno do servidor.' });
    }
});

// NOVA ROTA PARA CRIAR UMA CORRIDA
app.post('/api/rides', authenticateToken, async (req, res) => {
    const { retirada, destino, peso, distancia, total } = req.body;
    const usuario_id = req.user.id;

    if (!retirada || !destino || !peso || !distancia || !total) {
        return res.status(400).json({ success: false, message: 'Dados da corrida incompletos.' });
    }

    try {
        // Você precisará de uma tabela 'corridas' no seu banco de dados
        const sql = 'INSERT INTO corridas (usuario_id, endereco_retirada, endereco_destino, peso_kg, distancia_km, valor_total, status) VALUES (?, ?, ?, ?, ?, ?, ?)';
        await db.query(sql, [usuario_id, retirada, destino, peso, distancia, total, 'solicitada']);
        res.status(201).json({ success: true, message: 'Corrida solicitada com sucesso!' });
    } catch (error) {
        console.error('Erro ao solicitar corrida:', error);
        res.status(500).json({ success: false, message: 'Erro interno do servidor.' });
    }
});


// 6. INICIALIZAÇÃO DO SERVIDOR HTTPS
try {
    const sslOptions = {
      key: fs.readFileSync(path.join(__dirname, 'key.pem')),
      cert: fs.readFileSync(path.join(__dirname, 'cert.pem'))
    };

    https.createServer(sslOptions, app).listen(PORT, () => {
        console.log(`Servidor HTTPS rodando em: https://localhost:${PORT}`);
    });
} catch(error) {
    console.error('Não foi possível iniciar o servidor HTTPS. Verifique se os arquivos key.pem e cert.pem existem. Rodando em HTTP...');
    app.listen(PORT, () => {
        console.log(`Servidor HTTP rodando em: http://localhost:${PORT}`);
    });
}