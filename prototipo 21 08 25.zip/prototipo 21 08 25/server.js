// server.js (Versão com Autenticação JWT)

// 1. IMPORTAÇÃO DOS MÓDULOS
const fs = require('fs');
const https = require('https');
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const path = require('path');
const jwt = require('jsonwebtoken'); // <-- NOVO

// 2. CONFIGURAÇÃO DO SERVIDOR EXPRESS
const app = express();
const PORT = 3000;
// IMPORTANTE: Troque esta chave por uma string longa e aleatória em um ambiente de produção!
const JWT_SECRET = 'sua-chave-secreta-muito-segura-e-dificil-de-adivinhar'; // <-- NOVO

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 3. CONEXÃO COM O BANCO DE DADOS
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'ags_motoboy',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
}).promise();

// 4. MIDDLEWARE DE AUTENTICAÇÃO (NOVO)
// Esta função irá verificar o token em rotas protegidas
const authenticateToken = (req, res, next) => {
    // O token geralmente vem no cabeçalho de autorização no formato "Bearer TOKEN"
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) {
        // 401 Unauthorized: O cliente não enviou um token
        return res.status(401).json({ success: false, message: 'Acesso negado. Nenhum token fornecido.' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            // 403 Forbidden: O token é inválido ou expirou
            return res.status(403).json({ success: false, message: 'Token inválido ou expirado.' });
        }
        // Se o token for válido, adicionamos o payload do usuário ao objeto de requisição
        req.user = user;
        next(); // Passa para a próxima função (a rota em si)
    });
};


// 5. ROTAS

// Rotas públicas (não precisam de autenticação)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index1.html'));
});

app.post('/register', async (req, res) => {
    // Lógica de registro (permanece a mesma)
    const { nome, nickname, cpf, cep, nascimento, sexo, email, senha } = req.body;
    if (!nome || !nickname || !cpf || !cep || !nascimento || !sexo || !email || !senha) { return res.status(400).json({ success: false, message: 'Todos os campos são obrigatórios!' }); }
    const hoje = new Date(); const dataNascimento = new Date(nascimento); let idade = hoje.getFullYear() - dataNascimento.getFullYear(); const m = hoje.getMonth() - dataNascimento.getMonth(); if (m < 0 || (m === 0 && hoje.getDate() < dataNascimento.getDate())) { idade--; } if (idade < 18) { return res.status(400).json({ success: false, message: 'O cadastro não é permitido para menores de 18 anos.' }); }
    try {
        const salt = await bcrypt.genSalt(10); const senhaHash = await bcrypt.hash(senha, salt);
        const sql = `INSERT INTO usuarios (nome_completo, nickname, cpf, cep, data_nascimento, sexo, email, senha_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
        await db.query(sql, [nome, nickname, cpf, cep, nascimento, sexo, email, senhaHash]);
        res.status(201).json({ success: true, message: 'Usuário cadastrado com sucesso!' });
    } catch (error) { console.error('Erro no servidor ao registrar:', error); if (error.code === 'ER_DUP_ENTRY') { return res.status(409).json({ success: false, message: 'CPF, Nickname ou E-mail já cadastrado.' }); } res.status(500).json({ success: false, message: 'Erro interno no servidor.' }); }
});

// Rota de Login (MODIFICADA)
app.post('/login', async (req, res) => {
    const { usuario, senha } = req.body;
    if (!usuario || !senha) { return res.status(400).json({ success: false, message: 'Usuário e senha são obrigatórios.' }); }
    try {
        const sql = 'SELECT id, nickname, email, senha_hash FROM usuarios WHERE email = ? OR nickname = ?';
        const [rows] = await db.query(sql, [usuario, usuario]);
        if (rows.length === 0) { return res.status(404).json({ success: false, message: 'Usuário não encontrado.' }); }
        const user = rows[0];
        const senhaCorreta = await bcrypt.compare(senha, user.senha_hash);
        if (!senhaCorreta) { return res.status(401).json({ success: false, message: 'Senha incorreta.' }); }

        // --- GERAÇÃO DO TOKEN JWT ---
        // Criamos o "payload", que são os dados que queremos guardar dentro do token.
        // NUNCA inclua dados sensíveis como a senha aqui.
        const payload = {
            id: user.id,
            nickname: user.nickname
        };

        // Assinamos o token com nosso segredo e definimos um tempo de expiração.
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '8h' }); // Token válido por 8 horas

        // Enviamos o token de volta para o cliente.
        res.status(200).json({
            success: true,
            message: 'Login bem-sucedido!',
            token: token // <-- TOKEN ENVIADO AQUI
        });

    } catch (error) { console.error('Erro no servidor ao fazer login:', error); res.status(500).json({ success: false, message: 'Erro interno no servidor.' }); }
});

// Rota de exemplo protegida por autenticação (NOVO)
app.get('/api/dados-usuario', authenticateToken, async (req, res) => {
    // Graças ao middleware, se chegamos até aqui, o token é válido.
    // O middleware também adicionou os dados do usuário em `req.user`.
    try {
        const sql = 'SELECT id, nome_completo, nickname, email, foto_perfil_url FROM usuarios WHERE id = ?';
        const [rows] = await db.query(sql, [req.user.id]);

        if (rows.length > 0) {
            res.json({ success: true, user: rows[0] });
        } else {
            res.status(404).json({ success: false, message: 'Usuário não encontrado no banco de dados.' });
        }
    } catch (error) {
        console.error('Erro ao buscar dados do usuário:', error);
        res.status(500).json({ success: false, message: 'Erro interno do servidor.' });
    }
});


// 6. INICIALIZAÇÃO DO SERVIDOR HTTPS
try {
    const sslOptions = {
      key: fs.readFileSync(path.join(__dirname, 'key.pem')),
      cert: fs.readFileSync(path.join(__dirname, 'cert.pem'))
    };

    https.createServer(sslOptions, app).listen(PORT, () => {
        console.log(`Servidor HTTPS rodando em: https://localhost:${PORT}`);
    });
} catch(error) {
    console.error('Não foi possível iniciar o servidor HTTPS. Verifique se os arquivos key.pem e cert.pem existem. Rodando em HTTP...');
    app.listen(PORT, () => {
        console.log(`Servidor HTTP rodando em: http://localhost:${PORT}`);
    });
}